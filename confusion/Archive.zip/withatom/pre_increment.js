let amount = 100
console.log(++amount);