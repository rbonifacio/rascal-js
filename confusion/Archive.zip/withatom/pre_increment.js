var index = 1;
while (++index < 10) {
    console.log(index);
    break;
}



// 2
// revisado ok
