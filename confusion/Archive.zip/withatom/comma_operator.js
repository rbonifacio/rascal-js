let V1 = 5, V2 = 10;
V1 = (V2 = 1, 2);

console.log(V1+V2);


// revisado ok

// 3