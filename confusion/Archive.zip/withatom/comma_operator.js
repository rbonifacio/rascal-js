let index = 0
let age = (index++, 7)
console.log(age)
console.log(index)


// montar desenho experimental

// pesquisa menos de 10 minutos

// quem respondeu com atomo, nao pode responder sem atomo

// dois conjuntos de 7 

// 20 parcipantes em grupos de 2

