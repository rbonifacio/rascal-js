let V1 = 3;
let V2 = 5;
let V3 = 0;
while (V1 != V2 && ++V1) {
    V3++;
}
console.log(V1 + V3);


// revisado ok

// 7