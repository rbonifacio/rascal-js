function foo(){
    console.log("Foo");
}

let variable = 1;
variable && foo();
console.log(variable);