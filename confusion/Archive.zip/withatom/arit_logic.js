let array_1 = [1,2,3];
let array_2 = [2,3,2];
if(array_1.length - array_2.length){
    console.log(true);
}
else{
    console.log(false);
}

//revisado ok
// false