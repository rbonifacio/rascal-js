let variable = 100
if((3-3)*(variable+2)){
    console.log("foo")
}
console.log("foo")