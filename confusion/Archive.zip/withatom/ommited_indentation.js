let V1 = 1, V2 = 2
if (V1 > V2)
V2 = 1
V1 = 2
console.log(V2+V1)

// revisado ok
// 4