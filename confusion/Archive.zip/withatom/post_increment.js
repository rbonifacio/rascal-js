let dogAge = 7;
let fooDog = dogAge++;
console.log(fooDog);