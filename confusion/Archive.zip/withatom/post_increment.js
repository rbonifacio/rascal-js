let V1 = 0;
if (V1++ == 0) {
    console.log(true);
}
else {
    console.log(false);
}


// true

//revisado ok
 