let V1 = 10, V2 = 3;
if (!(V1 % V2)){
    console.log(true);
}
else{
    console.log(false);
}

// revisado ok , exemplo do atoms
// false