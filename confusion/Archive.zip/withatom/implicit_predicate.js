if(100%2)
    console.log("foo")
console.log("bar")