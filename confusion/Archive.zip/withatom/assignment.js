

let i = j = 100;
console.log(i+j)