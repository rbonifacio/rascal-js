function resetSchedulerState () {
    let activatedChildren = {length: 10};
    let index = length = activatedChildren.length = 0;
    console.log(index);
}
resetSchedulerState();

 // revisado ok  , pego do vue
 // 0