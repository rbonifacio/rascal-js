let weight = 100
let elevator = weight > 100 ? weight/2 : weight;
console.log(elevator)