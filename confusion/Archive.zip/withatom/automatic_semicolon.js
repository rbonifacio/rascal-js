function example(){
    return 
        10
}
if(example() == 10){
    console.log(true);
}
else{
    console.log(false);
}

// revisado ok, pinta no paint depois
return 10 // <--- cor de exemplo

// false