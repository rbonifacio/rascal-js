let index = 0;
index++
testing = 100

console.log(testing)
console.log(index)