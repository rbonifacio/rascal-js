let V1 = 1;
let V2 = 11;
let V3 = 0;
while (V1 != V2) {
    V1++;
    V3++;
}
console.log(V1+V3);

// 21
// revisado ok