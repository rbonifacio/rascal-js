function printNumber(){
    console.log("number")
}

const number = 1
if(number){
    console.log(1);
}