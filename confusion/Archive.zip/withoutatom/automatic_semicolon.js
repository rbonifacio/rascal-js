function example(){
    return 10;
}

if(example() == 10){
    console.log(true);
}
else{
    console.log(false);
}
// true
// revisado ok, pinta no paint depois
