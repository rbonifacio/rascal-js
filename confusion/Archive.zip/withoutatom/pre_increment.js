let age = 10;
age +=1;
console.log("He is " + age)