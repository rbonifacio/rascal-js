var index = 0;
index = index + 1;
while (index < 10) {
    console.log(index);
    index = index + 1;
    break;
}

/* .... */

// 1
// revisado ok



