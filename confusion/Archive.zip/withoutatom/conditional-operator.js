let index = 10;
if(index > 10){
    console.log(index/10)
}
else{
    console.log(index)
}