let config = {size: 3, isActive: false}
let _config;
if(config.isActive === true){
    _config = config;
}
else{
    _config = {size: 10};
}
console.log(_config.size);

// 10
// revisado ok