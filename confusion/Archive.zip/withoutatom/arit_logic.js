if((100-100) && (100*100))
    console.log("foo")