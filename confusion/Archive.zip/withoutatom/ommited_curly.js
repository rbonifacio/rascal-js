console.log("foo")
if(true){
    console.log("foo")
}
