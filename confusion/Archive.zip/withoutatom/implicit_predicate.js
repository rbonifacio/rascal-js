let V1 = 1, V2 = 2;
if ((V2 - V1) == 0){
    console.log(true);
}
else{
    console.log(false);
}

// false
 // revisado ok, do atom