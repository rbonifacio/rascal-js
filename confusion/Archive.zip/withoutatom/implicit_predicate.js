let number = 4;
if(number%2 != 0)
    console.log("foo")
console.log("bar")