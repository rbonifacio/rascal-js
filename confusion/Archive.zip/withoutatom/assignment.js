let subCounter;
let counter = 100;
subCounter = counter;