let V1 = 0;
if (V1 == 0) {
    console.log(true);
}
else {
    console.log(false);
}
V1 = V1 + 1;
 
// true
//revisado ok
 