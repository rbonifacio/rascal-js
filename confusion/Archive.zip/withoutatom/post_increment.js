let i = 0
let j = i;
i += 1;
console.log(j);